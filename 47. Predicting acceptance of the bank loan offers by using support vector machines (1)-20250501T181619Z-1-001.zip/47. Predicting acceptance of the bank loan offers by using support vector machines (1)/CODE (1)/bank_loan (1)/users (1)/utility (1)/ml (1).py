
import os
for dirname, _, filenames in os.walk('C:\\Users\\DATA_POINT_INFO\\OneDrive\\Desktop\\bankloan'):
    for filename in filenames:
        print(os.path.join(dirname, filename))
import numpy as np 
import pandas as pd 
df=pd.read_csv('C:\\Users\\DATA_POINT_INFO\\OneDrive\\Desktop\\bankloan\\Bank_Personal_Loan_Modelling.csv')
df
df.info()
df['Personal Loan'].value_counts()
X=df.drop('Personal Loan',axis=1)
y=df['Personal Loan']
from sklearn.model_selection import train_test_split
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=1)
from sklearn.svm import SVC
svm_model = SVC(kernel='linear')  # You can choose different kernels like 'rbf' or 'poly' if needed
svm_model.fit(X_train, y_train)
y_test_pred = svm_model.predict(X_test)
y_test_pred

# /////////////////////
# mlapp/views.py

import os
import numpy as np
import pandas as pd
from django.shortcuts import render
from django.http import HttpResponse

from sklearn.svm import SVC
from sklearn.model_selection import train_test_split

def machine_learning_view(request):
    # Your machine learning code here

    for dirname, _, filenames in os.walk('C:\\Users\\DATA_POINT_INFO\\OneDrive\\Desktop\\bankloan'):
        for filename in filenames:
            print(os.path.join(dirname, filename))

    df = pd.read_csv('C:\\Users\\DATA_POINT_INFO\\OneDrive\\Desktop\\bankloan\\Bank_Personal_Loan_Modelling.csv')

    # Rest of your code for data processing, model training, and predictions
    X = df.drop('Personal Loan', axis=1)
    y = df['Personal Loan']

    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.3, random_state=1)

    svm_model = SVC(kernel='linear')
    svm_model.fit(X_train, y_train)

    # Make predictions
    y_test_pred = svm_model.predict(X_test)

    # You can use y_test_pred for further processing or display it in the HttpResponse
    result = "Predictions: " + str(y_test_pred)
    return HttpResponse(result)

# mlapp/views.py

from django.shortcuts import render
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

def confusion_matrix_view(request):
    # Calculate accuracy, confusion matrix, and classification report
    accuracy = accuracy_score(y_test, y_test_pred)
    conf_matrix = confusion_matrix(y_test, y_test_pred)
    classification_rep = classification_report(y_test, y_test_pred)

    # Pass the results to the template
    context = {
        'accuracy': accuracy,
        'confusion_matrix': conf_matrix,
        'classification_report': classification_rep,
    }

    return render(request, 'mlapp/confusion_matrix.html', context)
