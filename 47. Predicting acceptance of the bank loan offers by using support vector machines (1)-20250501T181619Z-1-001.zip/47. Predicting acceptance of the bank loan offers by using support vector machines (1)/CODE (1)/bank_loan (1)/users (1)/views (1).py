from django.shortcuts import render, HttpResponse
from .forms import UserRegistrationForm
from django.contrib import messages
from .models import UserRegistrationModel
from django.conf import settings

from django.core.files.storage import FileSystemStorage

# Create your views here.
def UserRegisterActions(request):
    if request.method == 'POST':
        form = UserRegistrationForm(request.POST)
        if form.is_valid():
            print('Data is Valid')
            form.save()
            messages.success(request, 'You have been successfully registered')
            form = UserRegistrationForm()
            return render(request, 'UserRegistrations.html', {'form': form})
        else:
            messages.success(request, 'Email or Mobile Already Existed')
            print("Invalid form")
    else:
        form = UserRegistrationForm()
    return render(request, 'UserRegistrations.html', {'form': form})

def UserLoginCheck(request):
    if request.method == "POST":
        loginid=request.POST.get("loginid")
        password=request.POST.get("pswd")
        print(loginid)
        print(password)
        try:
            check=UserRegistrationModel.objects.get(loginid=loginid,password=password)
            status=check.status
            if status=="activated":
                request.session['id']=check.id
                request.session['loginid']=check.loginid
                request.session['password']=check.password
                request.session['email']=check.email
                return render(request,'users/UserHome.html')
            else:
                messages.success(request,"your account not activated")
            return render(request,"UserLogin.html")
        except Exception as e:
            print('=======>',e)
        messages.success(request,'invalid details')
    return render(request,'UserLogin.html')
    
def UserHome(request):
    return render(request,"users/UserHome.html",{})



  
def view_data(request):
    from django.conf import settings
    import pandas as pd


    path= settings.MEDIA_ROOT + "//" + 'Bank_Personal_Loan_Modelling.csv'
    d = pd.read_csv(path)
    d = d.head(50)

    context = {'dataset': d}
    return render(request,'users/dataset.html',context) 

# /////////////////////////////////////////////    #
from django.shortcuts import render
import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.ensemble import RandomForestClassifier

from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
# df = pd.read_csv('C:\\Users\\DATA_POINT_INFO\\OneDrive\\Desktop\\bankloan\\Bank_Personal_Loan_Modelling.csv')
path= settings.MEDIA_ROOT + "//" + 'Bank_Personal_Loan_Modelling.csv'
df= pd.read_csv(path)
X = df.drop('Personal Loan', axis=1)
y = df['Personal Loan']
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=1)
svm_model = SVC(kernel='linear')  # You can choose different kernels like 'rbf' or 'poly' if needed
svm_model.fit(X_train, y_train)
y_test_pred = svm_model.predict(X_test)
y_test_pred

def confusion_matrix_view(request):
    # Calculate accuracy, confusion matrix, and classification report
    accuracy = accuracy_score(y_test, y_test_pred)
    conf_matrix = confusion_matrix(y_test, y_test_pred)
    classification_rep = classification_report(y_test, y_test_pred)

    # Pass the results to the template
    context = {
        'accuracy': accuracy,
        'confusion_matrix': conf_matrix,
        'classification_report': classification_rep,
    }

    return render(request, 'users/confusion_matrix.html', context)
 
# correlation
# views.py

# views.py

# from django.shortcuts import render
# import pandas as pd
# from django.conf import settings

# def calculate_correlation(request):
#     path= settings.MEDIA_ROOT + "//" + 'Bank_Personal_Loan_Modelling.csv'
#     df= pd.read_csv(path)

#     # Extract the attributes of interest
#     attributes_of_interest = [
#         'ID', 'Age', 'Experience', 'Income', 'Family', 'CCAvg',
#         'Education', 'Mortgage', 'Personal Loan', 'Securities Account',
#         'CD Account', 'Online', 'CreditCard'
#     ]

#     # Calculate the correlation matrix
#     correlation_matrix = df[attributes_of_interest].corr()

#     # Pass the correlation matrix data to the template
#     context = {'correlation_matrix': correlation_matrix}
#     return render(request, 'users/correlation.html', context)

import pandas as pd
import plotly.express as px
from django.shortcuts import render
from django.conf import settings

def calculate_correlation(request):
    path = settings.MEDIA_ROOT + "//" + 'Bank_Personal_Loan_Modelling.csv'
    df = pd.read_csv(path)

    # Extract the attributes of interest
    attributes_of_interest = [
        'ID', 'Age', 'Experience', 'Income', 'Family', 'CCAvg',
        'Education', 'Mortgage', 'Personal Loan', 'Securities Account',
        'CD Account', 'Online', 'CreditCard'
    ]

    # Calculate the correlation matrix
    correlation_matrix = df[attributes_of_interest].corr()

    # Convert the correlation matrix to a Plotly heatmap
    fig = px.imshow(correlation_matrix, x=attributes_of_interest, y=attributes_of_interest, zmin=-1, zmax=1)

    # Pass the Plotly figure to the template
    context = {'correlation_figure': fig.to_html()}
    return render(request, 'users/correlation.html', context)


import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.svm import SVC
from sklearn.preprocessing import LabelEncoder, OneHotEncoder
from django.shortcuts import render

def process_data(request):
    # Load your dataset containing the new independent variables and the 'Personal Loan' target variable
    # Replace 'your_dataset.csv' with the actual path to your dataset file
    path = settings.MEDIA_ROOT + "//" + 'Bank_Personal_Loan_Modelling.csv'
    dataset = pd.read_csv(path)
    dataset = dataset.drop(columns=['ID', 'ZIP Code', 'Education'])

    # Extract the independent variables (X) and the target variable (y)
    X = dataset.drop(columns=['Personal Loan'])
    y = dataset['Personal Loan']

    # # Encode categorical variables using one-hot encoding
    # categorical_features = ['Education', 'ZIP Code']
    # X = pd.get_dummies(X, columns=categorical_features)

    # Split the data into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)

    # Initialize a LabelEncoder for later use

    return X_train, X_test, y_train, y_test

def predict_personal_loan(request):
    if request.method == 'POST':
        # Assuming you have a form where users input the feature values
        # Modify these fields to match your form's input names
        age = float(request.POST['Age'])
        experience = float(request.POST['Experience'])
        income = float(request.POST['Income'])
        family = int(request.POST['Family'])
        ccavg = float(request.POST['CCAvg'])
        mortgage = float(request.POST['Mortgage'])
        securities_account = int(request.POST['Securities Account'])
        cd_account = int(request.POST['CD Account'])
        online = int(request.POST['Online'])
        credit_card = int(request.POST['CreditCard'])

        print('------ got values-----')
        print(credit_card)

        # Create a DataFrame with the input data
        input_data = pd.DataFrame({
            'Age': [age],
            'Experience': [experience],
            'Income': [income],
            'Family': [family],
            'CCAvg': [ccavg],
            'Mortgage': [mortgage],
            'Securities Account': [securities_account],
            'CD Account': [cd_account],
            'Online': [online],
            'CreditCard': [credit_card]
        })
        
        # Apply one-hot encoding to match the features used during training
        # categorical_features = ['Education', 'ZIP Code']
        # input_data = pd.get_dummies(input_data, columns=categorical_features)

        print('---- input data-----')

        # Load the label encoder and training data
        X_train, _, y_train, _ = process_data(request)
        print('Training Data Columns:', X_train.columns)

        print('-----process data---')

        # Create an SVM model with default hyperparameters
        svm_model = RandomForestClassifier()

        # Train the SVM model on the training data
        svm_model.fit(X_train, y_train)
        print('--- model fit done -----')

        # Make predictions on the new data
        predicted_personal_loan = svm_model.predict(input_data)[0]
        print('Input Data Columns:', input_data.columns)

        print('predicted_personal_loan : ', predicted_personal_loan)

        return render(request, 'users/result.html', {
            'predicted_personal_loan': predicted_personal_loan
        })

    return render(request, 'users/prediction_form.html')
